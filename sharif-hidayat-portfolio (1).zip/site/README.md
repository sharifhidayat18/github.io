# Sharif Hidayat · Portfolio

Minimalist one-page portfolio. Plain HTML/CSS/JS, no build step.

## Put it online with GitHub Pages

1. Create a new public repository on GitHub, e.g. `sharifhidayat.github.io` (gives you the shortest URL) or any name like `portfolio`.
2. Click **Add file → Upload files**, drag in everything from this folder (`index.html`, `assets/`, `.nojekyll`, `README.md`), then **Commit changes**.
3. Go to **Settings → Pages**. Under *Build and deployment*, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then **Save**.
4. After a minute your site is live at `https://<username>.github.io/` (or `https://<username>.github.io/portfolio/`).

## Editing

- All text lives in `index.html`. Search for the sentence you want to change.
- Images are in `assets/img/` as WebP. To swap one, replace the file but keep the same name.
- Instagram posts: find `var INSTAGRAM_POSTS = [];` near the bottom of `index.html` and paste post or reel links between the brackets, in quotes, separated by commas. They appear in the Instagram section automatically.
- Contact links (email, WhatsApp, Instagram, resume) are in the `<footer>` near the bottom.
- Colors and font are the CSS variables at the top of `<style>` (`--paper`, `--ink`, `--deep`, `--font`).
